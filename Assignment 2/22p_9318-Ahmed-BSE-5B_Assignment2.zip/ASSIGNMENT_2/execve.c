#include<stdio.h>
#include<unistd.h>
int main(int argc,char *argv[])
{
	char *env[]={NULL};//passing empty environment
	printf("Using execve:\n");
	execve("./a.out", argv, env);
	return 0;
}
