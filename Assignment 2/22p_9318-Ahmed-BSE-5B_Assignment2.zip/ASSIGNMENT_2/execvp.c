#include<stdio.h>
#include<unistd.h>
int main(int argc, char *argv[])
{
	printf("Using execvp:\n");
	//use argv[]
	execvp(argv[1],&argv[1]);
	perror("execvp failed");
	return 0;
}
