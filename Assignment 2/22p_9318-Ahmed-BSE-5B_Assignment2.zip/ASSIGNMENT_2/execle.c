#include<stdio.h>
#include<unistd.h>
int main()
{
	printf("Using execle:\n");
	execle("./a.out","a.out",NULL,NULL);//2 times null is for passing empty environments
	return 0;
}
