#include<stdio.h>
#include<unistd.h>
int main(int argc,char *argv[])
{
	printf("Using execv:\n");
	execv("./a.out", argv);//executing ./a.out
	return 0;
}
