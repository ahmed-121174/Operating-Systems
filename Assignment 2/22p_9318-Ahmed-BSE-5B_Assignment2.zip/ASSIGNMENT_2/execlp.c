#include<stdio.h>
#include<unistd.h>
int main()
{
       	printf("Using execlp:\n");
	execlp("./a.out","a.out",NULL);
	return 0;
}
