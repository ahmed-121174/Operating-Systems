#include<stdio.h>
#include<unistd.h>
int main()
{
       	printf("Using execl:\n");
	execl("./a.out","a.out",NULL);
	return 0;
}
